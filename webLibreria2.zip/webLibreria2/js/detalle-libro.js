// Obtener el ID del libro de la URL
$(document).ready(function () {
  const urlParams = new URLSearchParams(window.location.search);
  const libroId = urlParams.get('id');

  if (libroId) {
    // Lógica para mostrar los detalles del libro
    console.log(`Detalles del libro con ID: ${libroId}`);
    const book = books.find((b) => b._id == libroId);
    if (book) {
      /* Mostrar detalle del libro */

      /* Para etiquetas de titulo */
      $('#image').attr('src', book.thumbnailUrl);
      $('#title').text(book.title);

      /* Para etiquetas p */
      $('#isbn').html('<b>ISBN: </b>' + book.isbn);
      $('#price').html('&dollar;' + book.price);
      $('#longDescription').html(
        '<b>Descripción: </b>' +
          (book.longDescription ? book.longDescription : 'No tiene descripción')
      );

      let authorString = book.authors.join(', ');
      $('#authors').text(authorString);
      
      book.categories.forEach(cat => {
        const catItem = document.createElement("span")
        catItem.classList.add('badge')
        catItem.classList.add('text-bg-secondary')
        catItem.textContent=cat
        $('#categories').append(catItem)
      });
    }
  }
});
