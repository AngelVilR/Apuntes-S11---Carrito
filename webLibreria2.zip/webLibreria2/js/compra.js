function addToCart(element) {
	var libroParent = $(element).closest('div.libro-item')
    var id = element.dataset.id
    //Tiene el simbolo de moneda
	var price = $(libroParent).find('.libro-price').text()
    price= price.substring(1,price.length)
	var name = $(libroParent).find('.libro-name').text()
	var quantity = $(libroParent).find('.libro-quantity').val()
	//Item del carrito
	var cartItem = {
        id,
		name,
		price,
		quantity
	}
	//Obtener carrito actual
	var cartArray = new Array()
	if (localStorage.getItem('compra')) {
		cartArray = JSON.parse(localStorage.getItem('compra'))
	}
	if(cartArray.length>0){
		let itemIndex = cartArray.findIndex((obj) => obj.id == cartItem.id);
		//Si existe en los items del carrito
		if(itemIndex != -1){
			cartArray[itemIndex].quantity=cartItem.quantity
		}else{
			//Agregar item	
			cartArray.push(cartItem)
		}
		
	}else{
		//Nuevo carrito
		//Agregar item	
		cartArray.push(cartItem)
		
	}
	
	//Guardar
	localStorage.setItem('compra',  JSON.stringify(cartArray))
	console.log( JSON.parse(localStorage.getItem('compra')))
	$.notify("Libro agregado a la compra: "+cartItem.name, "success");
}
function removeCartItem(idLibro) {
	var cartArray = JSON.parse(localStorage.getItem('compra'))
	if (cartArray) {
		let index = cartArray.findIndex((obj) => obj.id == idLibro);
		cartArray.splice(index,1)
	}
	//Guardar
	localStorage.setItem('compra',  JSON.stringify(cartArray))
	$.notify("Libro Eliminado de la Compra", "warn");
	showDetailShop()
} 

function updateCartItemQty(element) {
	var idLibro = element.data('id')
	var quantity=element.val()
	var cartArray = JSON.parse(localStorage.getItem('compra'))
	if (cartArray) {
		let itemIndex = cartArray.findIndex((obj) => obj.id == idLibro);
		cartArray[itemIndex].quantity=quantity
	}
	//Guardar
	localStorage.setItem('compra',  JSON.stringify(cartArray))
	showDetailShop()
} 
 function emptyCart() {
	if (localStorage.getItem('compra')) {
		localStorage.removeItem('compra');
		showDetailShop()
	}
}
function showDetailShop() {
	var cartRowHTML = "";
	var itemCount = 0;
	var total = 0;

	var price = 0;
	var quantity = 0;
	var subTotal = 0;
	var cart = JSON.parse(localStorage.getItem('compra'))
	if (cart) {
		itemCount = cart.length;

		cart.forEach(function(item) {
		
			price = parseFloat(item.price);
			quantity = parseInt(item.quantity);
			subTotal = price * quantity

			cartRowHTML += `<div class="row mb-4 d-flex justify-content-between align-items-center">
                        <div class="col-md-3 col-lg-3 col-xl-3">
                          <h6 class="text-muted name-libro">${item.name}</h6>
                        </div>
                        <div class="col-md-3 col-lg-3 col-xl-2 d-flex">

                          <input min="0" name="quantity" value="${item.quantity}" type="number"
                            class="form-control form-control-sm quantity-libro" data-id="${item.id}" />

                        </div>
                        <div class="col-md-3 col-lg-2 col-xl-2 offset-lg-1">
                          <h6 class="mb-0 price-libro">&dollar; ${item.price}</h6>
                        </div>
                        
						<div class="col-md-3 col-lg-2 col-xl-2 offset-lg-1">
                          <h6 class="mb-0 subtotal-libro">&dollar;${subTotal.toFixed(2)}</h6>
                        </div>
						<div class="col-md-1 col-lg-1 col-xl-1 ">
                          <button type="button" class="btn btn-secondary"><i class="bi bi-trash" onclick="removeCartItem(${item.id})"></i></button>
                        </div>
                      </div>
                      <hr class="my-4">`;

			total += subTotal;
		});
	}

	$('#detail').html(cartRowHTML);
	$('#total-items').text(itemCount);
	$('#total-compra').text("$" + total.toFixed(2));
}

showDetailShop()
