async function codigoPostal(event) {
    event.preventDefault();
    const codPostal = document.getElementById("codigo").value;   
    const urlJSON = `https://api.zippopotam.us/US/${codPostal}`;
    document.getElementById("error").style.display="none";
    try {
        /* Validar rango de cod. postales */
        /* Eliminar cont si da error */

        /* Siempre que se coloque await, se colocar en asincrona (Async) */
        const response = await fetch(urlJSON);
        if (!response.ok) {
            document.getElementById("error").style.display="block";
            document.getElementById("error").innerText= "Código Postal no encontrado"
            throw new Error("Error: "+response.status+" "+response.statusText);
        } 
        const data = await response.json();
        /* Pais */
        document.getElementById("pais").textContent=data.country
        /* Abreviatura */
        document.getElementById("pais_abrev").textContent=data["country abbreviation"];
        /* Lugar */
        document.getElementById("lugar").textContent=data.places[0]["place name"];
        /* Estado */
        document.getElementById("estado").textContent=data.places[0].state;
        /* Abrev */
        document.getElementById("estado_abrev").textContent=data.places[0]["state abbreviation"];
        /* Longitud */
        document.getElementById("latitud").textContent=data.places[0].latitude;
        /* Latitud */
        document.getElementById("longitud").textContent=data.places[0].longitude;




        console.log(data);            
    } catch (error) {
        console.log("Error: ", error);
    }

}