function detalleLibro(id) {
  window.location.href = `detalle-libro.html?id=${id}`;
}
function displayBooks(data) {  
  $("#book-list").html('')
  data.forEach((book) => {
   
    const bookCol = document.createElement("div");
    bookCol.classList.add("col");

    const bookCard = `
              <div class="card shadow-sm text-center libro-item">
                  <div class="card-header">
                      <h4 class="card-title libro-name">${book.title}</h4>
                  </div>
                  <img class="card-img-top" style="max-height:460px;" role="img" src="${book.thumbnailUrl}" alt="Imagen" />
                  <div class="card-body">
                      <p class="card-title">ISBN: ${book.isbn}</p>
                      <h1 class="card-title libro-price" >&cent;${book.price}</h1>
                      <div class="input-group">
                        <div class="input-group-text">Cantidad</div>
                        <input type="text" class="form-control libro-quantity" name="quantity" value="1" size="2" />
                              
                      </div>
                     <div class="d-grid gap-2 d-md-flex justify-content-md-end">
                        <button type="button" class="btn btn-lg btn-success" onclick="comprarLibro(this)" data-id="${book._id}"><i class="bi bi-cart-plus"></i></button>
                        <button type="button" class="btn btn-lg btn-primary" onclick="detalleLibro(${book._id})" ><i class="bi bi-three-dots"></i></button>
                      </div>
                  </div>
          `;
    $("#book-list").append(bookCard);
  });
}
// Función para mostrar las opciones de filtro por categoría
function displayCategories() {
  var select = $('#filter');
  var categories = [];
  
  // Obtener todas las categorías únicas
  $.each(books, function(index, book) {
      $.each(book.categories, function(index, category) {
          if ($.inArray(category, categories) === -1) {
              categories.push(category);
              // Añadir opción al select
              select.append('<option value="' + category + '">' + category + '</option>');
          }
      });
  });
}
function comprarLibro(element){
    addToCart(element)
}
$(document).ready(function () {

  displayBooks(books) 
  displayCategories()
  $('#filter').change(function() {
    var category = $(this).val();
    var filteredBooks;    
    if (category === 'all') {
        filteredBooks = books;
    } else {
        filteredBooks = books.filter(function(book) {
            return book.categories.includes(category);
        });
    }    
    // Mostrar los libros filtrados
    displayBooks(filteredBooks);
});
});

