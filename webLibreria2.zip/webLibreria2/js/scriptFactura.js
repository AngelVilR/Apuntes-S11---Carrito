const fecha=document.getElementById("date")
const date=new Date()
//Obtener elementos de la fecha
let day=date.getDate()
let month= date.getMonth()+1
let year= date.getFullYear()

let fechaActual=`${day}-${month}-${year}`
let fechaActual2=day +"-"+ month +"-"+ year

fecha.innerHTML+=fechaActual
const tBody=document.getElementById("contenido-factura")
var filas=tBody.rows.length


//Agregar una nueva fila de detalle
document.getElementById("agregar").addEventListener("click",(e)=>{
    addNewRow()
})

addNewRow=()=>{
    const row =document.createElement("tr")
    row.className="fila-factura"
    row.innerHTML=`<td><input type="text" placeholder="Nombre Producto" class="form-control"></td>
    <td><input type="number" placeholder="0" name="cantidad[${filas}]" class="form-control cantidad" onkeyup="updateCalculos()" ></td>
    <td><input type="number" placeholder="0" name="precio[${filas}]" class="form-control precio" onkeyup="updateCalculos()"></td>
    <td><input type="number" placeholder="0" name="subtotal[]" class="form-control subtotal" readonly></td>
    <td style="text-align: right;">
      <button class="btn btn-outline-primary" onclick="deleteRow(this)">
          <i class="bi bi-trash3"> </i>
      </button>
  </td>`
  tBody.insertBefore(row,tBody.lastChild)
  filas++
}
//Calculos
updateCalculos = ()=>{
  //Obtener filas del detalle de la factura
  let rows=document.querySelectorAll("tr.fila-factura")
  rows.forEach((filaActual)=>{
    let cantidad=filaActual.querySelector(".cantidad").value
    //alert("Cantidad: " + cantidad)
    let precio=filaActual.querySelector(".precio").value
    subtotal= cantidad*precio
    filaActual.querySelector(".subtotal").value=subtotal 
  })
  calculoTotal2()
}
//Eliminar fila
function deleteRow(button){
    const row=button.parentElement.parentElement
    row.remove()
    calculoTotal2()
}
//Calcular total
calculoTotal = ()=>{
    let subtotales=document.getElementsByName("subtotal[]")
    let total=0
    for (let index = 0; index < subtotales.length; index++) {
        if(subtotales[index].value){
            total += parseFloat(subtotales[index].value)
        }
        document.getElementById("total").value=total 
    }
}
calculoTotal2 = ()=>{
    const subtotales=document.querySelectorAll(".subtotal")
    let sumaTotal=0
    subtotales.forEach(elemento=>{
        sumaTotal+=parseFloat(elemento.value)
    })
    document.getElementById("total").value=sumaTotal
}